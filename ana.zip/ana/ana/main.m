%{
cite as:

Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}





function main()
  
    
    ana = ANASingleObjective("F2");
    ana.numberOfAgents = 30;
    ana.maxIteration   = 500;
    ana.turns          = 30;
    
    % run
    ana.runANA();
    
    % print results
    ana.printMean();
    ana.printStandardDeviation();
end
