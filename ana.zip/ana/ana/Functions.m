
%{
cite as:

Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}



classdef Functions < handle
    
    properties
        functionName
    end
    
    methods
        function obj = Functions(functionName)
            if nargin > 0
                obj.functionName = functionName;
            end
        end
        
        % ----------------------------------------------------------------
        % Example function: "F1"
        % ----------------------------------------------------------------
        function fitness = function_1(~, xs)
            % F1: sum of (x - 30)^2
            xs = xs(:)';  % ensure row
            fitness = 0.0;
            for i = 1:length(xs)
                x = xs(i) - 30;
                fitness = fitness + x^2;
            end
        end
        
        
        function fitness = function_2(~, xs)
            % sum of abs(x-3) + product of abs(x-3)
            xs = xs(:)';
            sumVal = 0.0;
            prodVal = 1.0;
            for i = 1:numel(xs)
                x = abs(xs(i) - 3);
                sumVal  = sumVal + x;
                prodVal = prodVal * x;
            end
            fitness = sumVal + prodVal;
        end
        
      
        
        % --------------- Example "antenna_array_design" for demonstration -----------
        function fitness = antenna_array_design(~, xs)
            xs = xs(:)';  % row
            PI = pi;
            evalationAngle = 45; 
            beamangle = 90; 
            
            % Basic boundary check (demo)
            for j = 1:4
                if xs(j) > 2.0
                    xs(j) = 2.0 * rand();
                elseif xs(j) <= 0.125
                    xs(j) = 0.125 + xs(j)*rand();
                end
            end
            % Some pairwise tweak from your original
            for i = 1:4
                for j = i:4
                    if i~=j
                        xi = xs(i); xj = xs(j);
                        if (xi> xj) && ((xi-xj)<0.26)
                            xs(i) = xi + 0.125; 
                            xs(j) = xj - 0.125;
                        elseif (xj> xi) && ((xj -xi)<0.26)
                            xs(j) = xj + 0.125; 
                            xs(i) = xi - 0.125;
                        end
                    end
                end
            end
            % Summation
            sumVal = 0.0;
            for j = 1:4
                sumVal = sumVal + cos(2*PI*xs(j)*(cosd(evalationAngle)-cosd(beamangle))) ...
                               + cos(2.25*2*PI*(cosd(evalationAngle)-cosd(beamangle)));
            end
            fitness = 20 * log(abs(sumVal));
        end
        
        % ----------------------------------------------------------------
        %  Return dimension, lower/upper bound (as single scalars).
        % ----------------------------------------------------------------
        function dim = getDimensions(obj)
            switch obj.functionName
                case "antenna_array_design"
                    dim = 4;
                case "frequency_modulated_synthesis"
                    dim = 6;
                case "F1"
                    dim = 10;
                case "F2"
                    dim = 10;
                % add more mappings for "F3","F4",... or "CEC01", etc.
                otherwise
                    dim = 10;  % fallback
            end
        end
        
        function lb = getLowerBound(obj)
            % Return a single numeric scalar
            switch obj.functionName
                case "antenna_array_design"
                    lb = 0;
                case "frequency_modulated_synthesis"
                    lb = -6.4;
                case "F1"
                    lb = -100;
                case "F2"
                    lb = -10;
                % add more as needed
                otherwise
                    lb = -100; % fallback
            end
        end
        
        function ub = getUpperBound(obj)
            % Return a single numeric scalar
            switch obj.functionName
                case "antenna_array_design"
                    ub = 2.0;
                case "frequency_modulated_synthesis"
                    ub = 6.35;
                case "F1"
                    ub = 100;
                case "F2"
                    ub = 10;
                % add more as needed
                otherwise
                    ub = 100; % fallback
            end
        end
    end
end
