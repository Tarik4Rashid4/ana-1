%{
cite as:

Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}



classdef ANASingleObjective < handle
    properties
        functionName
        turns = 1
        maxIteration = 500
        numberOfAgents = 30
        dimension
        lowerBound   % single scalar
        upperBound   % single scalar
        
        func         % Functions object
        globalBest   % cell array storing best ants by iteration
        averageFitness
        meanList
        averageOver50Trails
        
        % For boundary logic
        agentRemainInsideBoundary = true
    end
    
    methods
        function obj = ANASingleObjective(functionName, varargin)
            if nargin >= 1
                obj.functionName = functionName;
                obj.func         = Functions(functionName);
                obj.dimension    = obj.func.getDimensions();
                obj.lowerBound   = obj.func.getLowerBound();  % single scalar
                obj.upperBound   = obj.func.getUpperBound();  % single scalar
            end
            % optional: parse varargin for maxIteration, numberOfAgents, turns, etc.
            
            obj.globalBest          = {};
            obj.averageFitness      = [];
            obj.meanList            = [];
            obj.averageOver50Trails = [];
        end
        
        function runANA(obj)
            % Minimal example of the main loop
            fprintf('Function Name: %s\n', obj.functionName);
            fprintf('Number of Agents: %d\n', obj.numberOfAgents);
            fprintf('Number of Iterations: %d\n', obj.maxIteration);
            fprintf('Number of Turns: %d\n', obj.turns);
            fprintf('Dimension: %d\n', obj.dimension);
            fprintf('Upper Bound: %g\n', obj.upperBound);
            fprintf('Lower Bound: %g\n', obj.lowerBound);
            
            for turn = 1:obj.turns
                % For each turn, reset
                obj.averageFitness = [];
                obj.globalBest     = {};
                
                % 1) Initialize ants
                workerAnts = cell(obj.numberOfAgents,1);
                for agent = 1 : obj.numberOfAgents
                    x   = obj.getRandomPosition();
                    ant = Ant(x, agent, obj.func, x);  % current=prev
                    workerAnts{agent} = ant;
                end
                
                % 2) Main iteration
                for it = 1:obj.maxIteration
                    % Find best so far
                    bestAnt = obj.getBestAnt(workerAnts);
                    
                    % If you want a quick log:
                    bestFitnessVal = bestAnt.getAntFitness(obj.functionName);
                    fprintf('\rTurn: %d/%d  Iteration: %d/%d  BestSoFar=%.5f', ...
                        turn, obj.turns, it, obj.maxIteration, bestFitnessVal);
                    
                    % for each ant, do some movement logic
                    for a = 1 : obj.numberOfAgents
                        ant = workerAnts{a};
                        % create a new random position
                        candidatePos = obj.getRandomPosition();
                        candidateAnt = Ant(candidatePos, 0, obj.func, ant.getX());
                        
                        if candidateAnt.getAntFitness(obj.functionName) < ...
                                ant.getAntFitness(obj.functionName)
                            % accept
                            ant.setPreviousX(ant.getX());
                            ant.setX(candidatePos);
                       
                        end
                        
                        workerAnts{a} = ant; % store back
                    end
                    
                    % track best
                    obj.globalBest{end+1} = obj.getBestAnt(workerAnts);
                    % track average
                    obj.averageFitness(end+1) = obj.getAverageFitness(workerAnts);
                end
                
                % after finishing the iterations for this turn,
                % store final stats
                best = obj.getBestAnt(workerAnts);
                obj.meanList(end+1) = best.getAntFitness(obj.functionName);
                obj.averageOver50Trails(end+1) = obj.getAverageFitness(workerAnts);
                fprintf('\n');
            end
            
            fprintf('Done all turns.\n');
        end
        
        function position = getRandomPosition(obj)
            % Generate a 1×dimension random vector in [lowerBound, upperBound]
            position = obj.lowerBound + ...
                       (obj.upperBound - obj.lowerBound).*rand(1, obj.dimension);
        end
        
        function bestAnt = getBestAnt(obj, ants)
            % Return the ant with minimal fitness
            bestAnt = ants{1};
            bestVal = bestAnt.getAntFitness(obj.functionName);
            for i = 2:numel(ants)
                fVal = ants{i}.getAntFitness(obj.functionName);
                if fVal < bestVal
                    bestAnt = ants{i};
                    bestVal = fVal;
                end
            end
        end
        
        function avgFit = getAverageFitness(obj, ants)
            total = 0.0;
            for i = 1:numel(ants)
                total = total + ants{i}.getAntFitness(obj.functionName);
            end
            avgFit = total / numel(ants);
        end
        
      
        % ----------------------------------------------------------------
        function printMean(obj)
            % Suppose "meanList" is the best for each turn
            mVal = mean(obj.meanList);
            fprintf('Mean of Best Over All Turns = %g\n', mVal);
        end
        
        function printStandardDeviation(obj)
            stdVal = std(obj.meanList);
            fprintf('Standard Deviation of Best Over All Turns = %g\n', stdVal);
        end
    end
end
