
%{
cite as:

Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}


classdef Ant < handle
    properties
        X
        PreviousX
        Dominated = true  % renamed from `isDominated`
        number
        fitness
    end
    
    methods
        function obj = Ant(position, number, fitnessObj, previousPosition)
            if nargin > 0
                obj.X         = position(:)';
                obj.PreviousX = previousPosition(:)';
                obj.number    = number;
                obj.fitness   = fitnessObj;
            end
        end
        
        function val = getX(obj)
            val = obj.X;
        end
        
        function setX(obj, p)
            obj.X = p(:)';
        end
        
        function val = getPreviousX(obj)
            val = obj.PreviousX;
        end
        
        function setPreviousX(obj, p)
            obj.PreviousX = p(:)';
        end
        
        function bool = isDominated(obj)
            bool = obj.Dominated;
        end
        
        function setIsDominated(obj, b)
            obj.Dominated = b;
        end
        
        function n = getNumber(obj)
            n = obj.number;
        end
        
        function setNumber(obj, num)
            obj.number = num;
        end
        
        function ft = getAntFitness(obj, functionName)
            ft = obj.dispatchFitness(functionName, obj.X);
        end
        
        function ft = getPreviousXFitness(obj, functionName)
            ft = obj.dispatchFitness(functionName, obj.PreviousX);
        end
        
        function str = toString(obj)
            posValues = sprintf('%g, ', obj.X);
            if ~isempty(posValues)
                posValues = posValues(1:end-2);
            end
            str = posValues;
        end
    end
    
    methods (Access = private)
        function ft = dispatchFitness(obj, functionName, position)
            switch functionName
                case "F1"
                    ft = obj.fitness.function_1(position);
                case "F2"
                    ft = obj.fitness.function_2(position);
                case "antenna_array_design"
                    ft = obj.fitness.antenna_array_design(position);
                % etc...
                otherwise
                    error('Unknown function name: %s', functionName);
            end
        end
    end
end
